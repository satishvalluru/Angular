import { Cart } from './cart.model';

describe('Cart', () => {
  it('should create an instance', () => {
    expect(new Cart()).toBeTruthy();
  });
});
