/**
 * @description This is Beneficiary Model
 */
export interface Beneficiary {
    id:number;
    frmaccount:string;
    benefaccount:string;
    accType:string;
    custname:string
}
